
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main() 
{
char* s = (char *)malloc(sizeof(char));
scanf("%s", s);
int str_len,i=0,temp;
str_len = strlen(s);
do    
{
temp=0;
for(i=0;i < str_len-1;)
{
if(s[i]==s[i+1])
{
temp=1;
for(int j=i;j<str_len-2;j++)
s[j]=s[j+2];
str_len = str_len-2;
}
else
i++;
}
s[str_len]='\0';
} 
while(temp==1 && str_len>0);
if(str_len!=0)
    printf("%s",s);
else  
    printf("Empty String");
    return 0;
}
