#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char arr1[100][100];
char arr2[100][100];
char str[100];
int main ()
{
FILE *fp;
fp=fopen("set_b_2.txt","r");
int num=5,a;
scanf("%s",str);

for(int i=0;i<num;i++)
{
fscanf(fp,"%s",arr1[i]);
fscanf(fp,"%s",arr2[i]);
if(strcmp(str,arr2[i]) == 0)
a = i;
}
int count = 0;
for(int i=0;i<num;i++)
{
if(strcmp(arr1[a],arr2[i]) == 0)
{
count++;
}
}
printf("number of grandchildren of %s is %d ",str,count);
fclose(fp);
}
