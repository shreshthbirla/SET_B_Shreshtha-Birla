#include <stdio.h>
#include <stdlib.h>

 
#define char_bits 1
#define int_bits  (sizeof(int) * char_bits)

void binarynum(unsigned n);
unsigned int reverse_bits(unsigned int num);

int main()
{
unsigned int data = 0;
unsigned int rev = 0;
    
printf("Enter the number : ");
scanf("%d",&data);
    
printf("\nbefore: " );
binarynum(data);
rev = reverse_bits(data);
printf("\nafter: " );
binarynum(rev);
    
return 0;
}

void binarynum(unsigned n)
{
short int x;
for (x = (int_bits -1) ; x >= 0 ; x--)
{
(n & (1 << x))? printf("1"): printf("0");
}	
}

unsigned int reverse_bits(unsigned int n)
{
unsigned int count = (int_bits -1); 
unsigned int temp = n;       
n >>= 1;
    
while(n)
{
temp <<= 1;    
temp |= n & 1;
       
n >>= 1; 
       
count--;
}
    
temp <<= count; 
    
return temp;
}
